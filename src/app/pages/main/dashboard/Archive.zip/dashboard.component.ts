import { Component, OnInit } from '@angular/core';
import { DashboardService } from './../../../services/dashboard/dashboard.service';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { Router } from "@angular/router";
import { AuthService } from './../../../services/auth/auth.service';
import * as pluginDataLabels from 'chartjs-plugin-datalabels';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  
  /* pie : start */
  public pieChartOptions: ChartOptions = {
    responsive: true,
    legend: {
      position: 'left',
      labels: {
        fontSize: 14,
        fontColor: '#1E2631',
      }
    },
    tooltips: {
      callbacks: {
        label: function(item, data) {
          let datasetIndex = item.datasetIndex;
          let lbl = data.labels[datasetIndex];
          return lbl.toString();
        },
        footer: function(item, data) {
          console.log("item", item);
          console.log("data", data);
          let index = item[0].index;
          let value = Number(data.datasets[0].data[index]);
          const label = value.toFixed(2) + ' %';
          return value == 0 ? '' : 'Production Rate: ' + label;
        }
      }
    },
    plugins: {
      datalabels: {
        formatter: (value, ctx) => {
          const label = value.toFixed(2) + ' %';
          return value == 0 ? '' : label;
        },
      },
    },
  };
  public pieChartLabels: Label[] = [];
  public pieChartData: number[] = [];
  public pieChartType: ChartType = 'pie';
  public pieChartLegend = true;
  public pieChartPlugins = [pluginDataLabels];
  piechartvalues: any = [];
  /* pie : end */

  /* bar : start */
  public barChartOptions: ChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    aspectRatio: 1,
    scales: {
      yAxes: [{
        scaleLabel: {
          display: true,
          labelString: 'No. of consumed (g)',
          fontSize: 14,
          lineHeight: 4,
          fontColor: '#05172e'
        },
        ticks: {
          min: 0,
          callback: function(label, index, labels) {
            let SI_POSTFIXES = ["", "K", "M", "G", "T", "P", "E"];
            let tier = Math.log10(Math.abs(label)) / 3 | 0;
            if(tier == 0) return label;
            let postfix = SI_POSTFIXES[tier];
            let scale = Math.pow(10, tier * 3);
            let scaled = label / scale;
            let formatted = scaled.toFixed(1) + '';
            if (/\.0$/.test(formatted))
              formatted = formatted.substr(0, formatted.length - 2);
            return formatted + postfix;
            /* let parts = label.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            return parts.join(".") + ' g'; */
          }
        }
      }]
    },
    tooltips: {
      callbacks: {
        title: (title, data) => {
          return null;
        },
        label: function(item, data) {
          /* console.log("item", item);
          if (Number(item.value) == 0) {
            return null;
          } else {
            let parts = item.value.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            return "Consumed: " + parts.join(".");
          } */
          return "House/Building no. " + item.label;
        },
        footer: function(item, data) {
          if (Number(item[0].value) == 0) {
            return null;
          } else {
            let parts = item[0].value.toString().split(".");
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            return "Consumed: " + parts.join(".") + ' g';
          }
        }
      }
    },
    plugins: {
      datalabels: {
        color: '#FFF',
        formatter: (value, ctx) => {
          let SI_POSTFIXES = ["", "K", "M", "G", "T", "P", "E"];
          let tier = Math.log10(Math.abs(value)) / 3 | 0;
          if(tier == 0) return value;
          let postfix = SI_POSTFIXES[tier];
          let scale = Math.pow(10, tier * 3);
          let scaled = value / scale;
          let formatted = scaled.toFixed(1) + '';
          if (/\.0$/.test(formatted))
            formatted = formatted.substr(0, formatted.length - 2);
          return formatted + postfix;
        },
      },
    },
  };
  public barChartLabels: Label[] = [];
  public barChartType: ChartType = 'bar';
  public barChartLegend = false;
  public barChartPlugins = [pluginDataLabels];

  public barChartData: ChartDataSets[] = [];
  barchartvalues: any = [];
  /* bar : end */

  dateToday: Date = new Date();
  type: number = 0;
  dashboard_data: any = null;
  feed_consumption_data: any = null;
  medicine_consumption_data: any = null;
  harvest_production_status_data: any = null;
  harvest_rate_data: any = null;
  recent_transactions_data: any = null;
  staff_activities_data: any = null;

  masonryItems = [
    {
      title: 'Feed Consumption',
      key: 'feed_consumption',
      url: '/performance-report/consumption/feeds'
    },
    {
      title: 'Medicine Consumption',
      key: 'medicine_consumption',
      url: '/performance-report/consumption/medicine'
    },
    {
      title: 'Harvest Production Status',
      key: 'harvest_production_status',
      url: '/daily-reports'
    },
    {
      title: 'Harvest Production Rate per houses',
      key: 'harvest_production_rate',
      url: null
    },
    {
      title: 'Recent Transactions',
      key: 'recent_transactions',
      url: '/transactions'
    },
    {
      title: 'Recent Staff Activities',
      key: 'recent_staff_activities',
      url: null
    }
  ];
  userProfile: any = [];
  constructor(
    private auth: AuthService,
    private dashboardService: DashboardService,
  ) {

  }

  ngOnInit() {
    this.auth.validateUserRole();
    this.getDashboard();
    this.getFeedConsumption();
    this.getHarvestRate();
    this.getHarvestStatus();
    this.getMedicineConsumption();
    this.getRecentTransactions();
    this.getStaffActivities();
  }
  async changeType() {
    this.type = this.type == 1 ? 0 : 1;
    await this.ngOnInit();
  }
  async getDashboard() {
    await this.dashboardService.getDashboard(this.type).then(res => {
      console.log("getDashboard", res);
      if (res['error'] == 0) {
        this.dashboard_data = res['data'];
      }
    }).catch(e => {
      console.log("e", e);
    });
  }
  async getFeedConsumption() {
    this.barChartLabels = [];
    this.barChartData = [];
    this.barchartvalues = [];
    await this.dashboardService.getFeedConsumption(this.type).then(res => {
      console.log("getFeedConsumption", res);
      if (res['error'] == 0) {
        this.feed_consumption_data = res['data'];
        res['data'].forEach(data => {
          this.barChartLabels.push(data.house_name);
          this.barchartvalues.push(data.consumed_feeds);
        });
        this.barChartData = [
          {
            data: this.barchartvalues,
            label: 'Consumed',
            backgroundColor: '#FF9F1A',
            hoverBackgroundColor: '#FFB247',
          }
        ];
      } else {
        this.barChartData = [
          {
            data: this.barchartvalues,
            label: 'Consumed',
            backgroundColor: '#FF9F1A',
            hoverBackgroundColor: '#FFB247',
          }
        ];
      }
    }).catch(e => {
      console.log("e", e);
      this.barChartData = [
        {
          data: this.barchartvalues,
          label: 'Consumed',
          backgroundColor: '#FF9F1A',
          hoverBackgroundColor: '#FFB247',
        }
      ];
    });
  }
  async getMedicineConsumption() {
    await this.dashboardService.getMedicineConsumption(this.type).then(res => {
      console.log("getMedicineConsumption", res);
      if (res['error'] == 0) {
        this.medicine_consumption_data = res['data'];
      }
    }).catch(e => {
      console.log("e", e);
    });
  }
  async getHarvestStatus() {
    await this.dashboardService.getHarvestStatus(this.type).then(res => {
      console.log("getHarvestStatus", res);
      if (res['error'] == 0) {
        this.harvest_production_status_data = res['data'];
      }
    }).catch(e => {
      console.log("e", e);
    });
  }
  async getHarvestRate() {
    this.piechartvalues = [];
    this.pieChartLabels = [];
    this.pieChartData = [];
    await this.dashboardService.getHarvestRate(this.type).then(res => {
      console.log("getHarvestRate", res);
      if (res['error'] == 0) {
        this.harvest_rate_data = res['data'];
        this.harvest_rate_data.forEach(data => {
          this.pieChartLabels.push('House/Building no. ' + data.house_name);
          if (data.production_rate == 0) {
            this.piechartvalues.push(0);
          } else {
            this.piechartvalues.push(Number(data.production_rate));
          }
        });
        this.pieChartData = this.piechartvalues;
      } else {
        this.pieChartData = [];
      }
    }).catch(e => {
      console.log("e", e);
      this.pieChartData = [];
    });
  }
  async getRecentTransactions() {
    await this.dashboardService.getRecentTransactions(this.type).then(res => {
      console.log("getRecentTransactions", res);
      if (res['error'] == 0) {
        this.recent_transactions_data = res['data'];
      }
    }).catch(e => {
      console.log("e", e);
    });
  }
  async getStaffActivities() {
    await this.dashboardService.getActivityLog().then(res => {
      console.log("getActivityLog", res);
      if (res['error'] == 0) {
        this.staff_activities_data = res['data'];
      }
    }).catch(e => {
      console.log("e", e);
    });
  }
  abbreviateNumber(number) {
    var SI_POSTFIXES = ["", "k", "M", "G", "T", "P", "E"];
    var tier = Math.log10(Math.abs(number)) / 3 | 0;
    if(tier == 0) return number;
    var postfix = SI_POSTFIXES[tier];
    var scale = Math.pow(10, tier * 3);
    var scaled = number / scale;
    var formatted = scaled.toFixed(1) + '';
    if (/\.0$/.test(formatted))
      formatted = formatted.substr(0, formatted.length - 2);
    return formatted + postfix;
  }
}
